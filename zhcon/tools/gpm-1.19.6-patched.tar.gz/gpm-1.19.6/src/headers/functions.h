/*
 * all function prototypes
 *
 * Copyright (c) 2001        Nico Schottelius <nico@schottelius.org>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */


#ifndef _GPMFUNC_INCLUDED
#define _GPMFUNC_INCLUDED

/* devfs.c */
int check_devfs( void ); /* checks for devfs */
int set_devfs(int devfs_id, char **console, char **basevc);
int set_devfs_onet(char **console, char **basevc);
char *ret_devfs(int devfs_id, int rettype);
char *ret_devfs_onet(int rettype);

#endif /* if not included */
