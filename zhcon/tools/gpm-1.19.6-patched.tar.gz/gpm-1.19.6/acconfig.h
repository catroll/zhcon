/* Copyright (C) 1998 Ian Zimmerman <itz@transbay.net> */

@TOP@

/* GPM release number as a string. */
#define GPM_RELEASE ""

/* RMEV release number as a string. */
#define RMEV_RELEASE ""

/* define if the __u32 type exists either in sys/types.h or in
   linux/types.h */
#undef HAVE___U32
